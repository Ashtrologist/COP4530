#include "Graph.hpp"

//Constructor for edge class
Edge::Edge(){
    distance1 = "";
    distance2 = "";
    lineWeight = 0;
}

//Deconstructor
Edge::~Edge(){}

void Graph::decidePath(map<string, string> startLabel, string endLabel, vector<string> &path){
	if (startLabel[endLabel] == "STOP")
		return;
	
	decidePath(startLabel, startLabel[endLabel], path); //creating path
	path.push_back(endLabel);
}

//This functions adds an edge
void Graph::addEdge(string label1, string label2, unsigned long weight){
    bool flag = false;
    bool flag2 = false;
    Edge *edge1 = new Edge();

    for(unsigned int j = 0; j < vertex.size(); j++){
        if(vertex.at(j) == label1){
            flag = true;
        }
        if(vertex.at(j) == label2){
            flag2 = true;
        }

        if((flag == true) && (flag2 == true)){
            edge1 -> distance1 = label1;
            edge1 -> distance2 = label2;
            edge1 -> lineWeight = weight;
            vertexEdge.push_back(edge1);
            return;

        }
    }
}

//function removes an edge
void Graph::removeEdge(string label1, string label2){
    Edge *edge1 = new Edge();

    for(unsigned long i = 0; i < vertexEdge.size(); i++){
        edge1 = vertexEdge[i];
        if((edge1 -> distance1 == label1) && (edge1 -> distance2 == label2)){
            vertexEdge.erase(vertexEdge.begin() + i);
        }
    }
}

//functions adds a vertex
void Graph::addVertex(string label){

    for(auto i : vertex){
        if(i == label)
            continue;
    }
    vertex.push_back(label);
}

//function removes a vertex
void Graph::removeVertex(string label){
    Edge *edge1 = new Edge ();
    for(unsigned long i = 0; i < vertex.size(); i++){
        if(vertex[i] == label){
            vertex.erase(vertex.begin() + i);

            for(unsigned long j = 0; j < vertexEdge.size(); j++){
                edge1 = vertexEdge[j];
                if((edge1 -> distance1 == label) || (edge1 -> distance2 == label)){
                    vertexEdge.erase(vertexEdge.begin() + j);
                }
            }
        }
    }
}

//
unsigned long Graph::shortestPath(std::string startLabel, std::string endLabel, std::vector<std::string> &path){
    priority_queue< pair<int, string>, vector <pair<int, string>> , greater<pair<int, string>>> direction;
    map<string, string> vertices;
    map<string, int> distance;
    string temporary = "";
    string temporary2 = "";
    list<pair<int, string>>::iterator it;

    for(const auto i : vertex){
        distance[i] = INT_MAX;
        vertices[i] = "STOP";
    }

    direction.push(make_pair(0, startLabel));
    distance[startLabel] = 0;

    while(!direction.empty()){
        temporary = direction.top().second;
        direction.pop();

        for(auto j : vertexEdge){

            int weight = j -> lineWeight;
            if(j -> distance1 == temporary){
                temporary2 = j -> distance2;
            }

            else if(j -> distance2 == temporary){
                temporary2 = j -> distance1;
            }

            else
                continue;
            
            if(distance[temporary2] > distance[temporary] + weight){
                vertices[temporary2] = temporary;
                distance[temporary2] = distance[temporary] + weight;
                direction.push(make_pair(distance[temporary2], temporary2));
            }   
        }
    }

    path.push_back(startLabel);
    decidePath(vertices, endLabel, path);

    return distance[endLabel];

}


